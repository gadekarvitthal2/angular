// function vitthal(name,lastname,id,city){
//     this.name=name;
//     this.lastname=lastname;
//     this.id=id;
//     this.city=city;
    
    

// }

// var vitthal1=new vitthal("satyam","chobe",211,"jalna");
// vitthal.prototype.nationality = "hindu";
// vitthal.prototype.name = function(){
//     return this.name+this.lastname;
//     }


 


// console.log(vitthal1.nationality); 
// console.log(vitthal1.name());