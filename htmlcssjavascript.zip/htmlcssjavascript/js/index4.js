
var arr = [
  {
    "name": "rohit",
    "age": "25",
    "location": "mumbai"
  },
  {
    "name": "virat",
    "age": "24",
    "location": "banglore"
  },
  {
    "name": "dinesh",
    "age": "27",
    "location": "mumbai"
  },
  {
    "name": "shikar",
    "age": "27",
    "location": "delhi"
  }

];
var sorted = [];
var mergedarr = [];
for (var i = 0, max = arr.length; i < max; i++) {
  if (sorted[arr[i].name] == undefined) {
    sorted[arr[i].name] = [];
  }
  sorted[arr[i].name].push(arr[i]);

}
console.log(sorted["shikar"]);
console.log(sorted["virat"]);
console.log(sorted["dinesh"]);
console.log(sorted["rohit"]);















// var sorted = [];
// var mergedarr=[];
// for( var i = 0, max = arr.length; i < max ; i++ ){
//  if( sorted[arr[i].name] == undefined ){
//   sorted[arr[i].name] = [];
//  }
//  sorted[arr[i].name].push(arr[i]);
//  mergedarr.push(arr[i])  //here we added in single array




// }

// console.log(sorted["shikar"]);
// console.log(sorted["virat"]);
// console.log(sorted["dinesh"]);
// console.log(sorted["rohit"]);

    // console.log(mergedarr);







