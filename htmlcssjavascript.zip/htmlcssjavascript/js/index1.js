// let input;
// input = 1;

// switch(input){
//     case 1:{
//         document.write("contine....");
//         break;
//     }
//     case 2:
//         document.write("continue");
//         break;
//     case "no":
//         document.write("end");
//         break;
//     case "not":
//         document.write("end...");
//         break;
//     default:
//         document.write("pls enter correct input");        
// }
//----------------------------------------------------------------

// let counter = 10;

// while(counter >=1)
// {
//     document.write("vitthal gadekar");
//     i--;=

// }
//------------------------------------------------------------------
// let i = 0;
// let count = 0;
// while (i <= 10) {
//     if (i % 2 == 0) {
//         count = count + i;
//     }
//     i++;
// }
// document.write(count); 
//------------------------------------------------------------------
// label:for(let i=1;i<10;i++){
    
//     // if(i==3){
//     //     continue;
//     // }
//     document.write(i);
//     document.write("<br>");
//     for(let j=1;j<=2;j++){
        
//         document.write(j +":-"+"vitthal");
//         document.write("<br>")
//         break label;
        
//     }
// }
// let age = prompt("enter your age");
// if(age !==null){
//     document.write("your age is");
//     document.write("<br>");
//     document.write(age);
// }
// else{
//     document.write("your are not entered anything");
// }
//-------------------------------------------------
// let responce=confirm("do you want to delete");
// if(responce){
//     document.write("document has been deleted");

// }
// else{
//     document.write("not deleted");
// }
//-------------------------------------------------------------------
// let type= "hello";
// console.log(typeof type);
// let newtype=Boolean(type);
// console.log(newtype);
// console.log(typeof newtype);
//---------------------------------------------------------------------

// let array1=["vitthal","shyam","ram","kanyayaa"];

// array1.forEach(value1 =>{
//     console.log(value1);
// })


//----------------------------------------------------------------------
// function addition(number1,number2){
//     let number3=number1+number2;
//     console.log(number3);
// }
// addition(10,12);
//-----------------------------------------------------------------

// function fun(number){
//     for(i=1;i<=10;i++){
//         document.write(`19 + ${i} = ${number*i}`);
//         document.write("<br>");
//     }
// }

// fun(19);
// alert("hi");
//---------------------------------------------------------------------------

// function add(){
    
//    if(arguments.length==0){
//     console.log("please Enter arguments");
//    }
//   else{
//     console.log(arguments[1]);
//     let sum=0;
//     for(i=0;i<arguments.length;i++){
        
//         sum=sum+arguments[i];
//         console.log("sum is");
        
//     }
//     console.log(sum);
//     return 25;

    
    
//   } 
// }  

//   add(2,3);

//   let func1=add;
//   console.log(func1);

//--------------------------------------------------------------
// function display(){
//     console.log(arguments.length);
// }

// display(2,3);

// function add(a,b){

//     return b-a;

// }

//---------------------------------------------------------------
// let z=add(2,3);
// console.log(z);

// function add(num1,num2){
//     let i =num1+num2;
//     return i;
// }

// let j=add(2,3);

// console.log("addition is"+j);

// function add(a,b){
//     let v1=a+b;
//     return v1;

// }
// let v2=add(25,25);
// console.log("this is the addtion"+v2);

// function add(){
//     let Result=25;
// console.log(Result);
// }
// function sub(){
//     let Result=35;
//     console.log(Result);
// }
// add();
// sub();
//---------------------------------------------------------------
//immidiate invoked function
(function(){
    console.log("hello world");
    

}());

//if we use others code at time we use annonumus function for 
//at that time we use annonimus function
//they need not pass the value 


