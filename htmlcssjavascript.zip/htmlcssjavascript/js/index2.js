//object and defining and accecing object
// let person ={
//     name :"vitthal",
//     mo_number:9862846662,
//     student_id:11,
//     height:5.8,

// }


// console.log(person.student_id);

// person.name="shyam";//updating value
// console.log(person);
// person.walk="yes";//adding

// delete person.walk;
// console.log(person.walk);this is for serching property;
// console.log("height" in person); second way of searching;
// console.log(person);
//----------------------------------------------
// for (let key1 in person) {  //one by one object created
//     console.log(key1+person[key1]);//first properity and value

// }

//-------------------------------------------------------------

//way to object creation

// let bank = {
//     name:"SBI",
//     branch_name:"bhokardan",
//     ifsc_code:252512,
   
// }
// bank.sayhello=function(){
//     console.log("hello");
// }
// bank.sayhello();

//second way

// function sayhello2(){
//     console.log("say hello2");
// }

// bank.fun2=sayhello2;

// bank.fun2();

//third way
// let bank = {
//     name:"SBI",
//     branch_name:"bhokardan",
//     ifsc_code:252512,
//     sayhello3:function(){
//         console.log("hello 3");
//     }
   
// }
// bank.sayhello3();

//------------------------------------------------------------------
//accesing property of another object by using function
// let bank = {
//     name:"SBI",
//     branch_name:"bhokardan",
//     hobby(){
//         console.log("this is my"+car.brand+"and"+"brand is"+car.model);
//     },
//     ifsc_code:252512,
// }


// let car={
//     brand:"mahindra",
//     model:"xuv",   
// }
// bank.hobby();
//---------------------------------------------------------------------
// console.log(Math.floor(Math.random()*11));
// console.log(Math.floor(Math.random()*(25-15)+15)); range is 25-15

//--------------------------------------------------------------------
//date Object
// var y=new Date("2022,may,23,,11,25,58,14");

// console.log(y);
// x.getTime();
//------------------------------------------------------------------
//getter and setter

let get1={
    name:'vitthal',
    id:"5525",
    get gettr(){
        return this.name.toUpperCase;
    }


}
get1.gettr();
console.log(get1.name);














