
let bank={
    itemname:"samsung",
    price:10000,
    discount:10,
    itemcode:51,
    sayhello:function(){
        return this.price*this.discount/100;

    }
}
//------------------------------------------------------
//constructor function
function Person(name,price,discount,itemcode){
    return {
        name:name,
        price:price,
        discount:discount,
        itemcode:itemcode
    }

}

const calculate=new Person('vitthal',50000,'apple',52)
console.log(calculate);
//-----------------------------------------------------------------------------------
function Bank(name,price,discount,itemcode){
    this.firstnam=name,
    this.price=price,
    this.discount=discount,
    this.itemcode=itemcode
    this.discountvalue=function(){
        return price*discount/100;
    }
 
}

const calculate1=new Bank('sujata',25000,10,53);
console.log(calculate1.discountvalue());