// let arr=[1,22,15,0,1,85,12,65,75];

// let filterarray=arr.filter(function(val){
//     return val>10;
// });

// // console.log(filterarray);

// let filerunonimus=arr.filter((val)=>{return val>10});
// console.log(filerunonimus);

//----------------------------------------------------------------------
//filter function in array included object

let arr=[{
    name:"vitthal",
    surname:"gadekar",
    designation:"engineer"
},

{
    name:"shyam",
    surname:"gadekar",
    designation:"teacher"
},{
    name:"shubham",
    surname:"gadekar",
    designation:"engineer"
},{
    name:"satyam",
    surname:"gadekar",
    designation:"plumber"
}];

// let vitthal=arr.filter((val)=>{
//     if(val.designation=="engineer"){
//         return val;
//     };
// });

// let vitthal=arr.filter((val)=>val.designation=="engineer");

let vitthal=arr.filter(function(val){
    return val.designation=="engineer";
})
console.log(vitthal);


