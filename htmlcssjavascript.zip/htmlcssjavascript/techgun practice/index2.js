//annonymus function

// let show=(function (){(
//     console.log("hello world")

// )}());
//objects in javascript
let person={
    name:"vitthal",
    mobile:"7219039013",
    age:25
}

// person.savname=554466;
// delete person.savname;
// person.name="shyam";
// console.log("name" in person);
// for(let key in person){
//     console.log(key +person[key]);
// }
// for (const key in person) {
//     if (Object.hasOwnProperty.call(person, key)) {
//         const element = person[key];
        
//     }
// }
//first way to call a method of object
// person.method1=function (){
//     console.log("method1 method is successfully called");
// }

// person.method1();

//second way of call a method of object;

// function shyam(){
//     console.log("Hello !");

// }
// person.variable2=shyam;//assigning to function to variable;

// person.variable2();//function call



