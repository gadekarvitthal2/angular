// class employee {
//     constructor(n) {
//         this.name = n;
//         console.log("constructor called");
//     }

//     static sayhello() {
//         console.log("hello");
//     }
// }
// // let emp1 = new employee();
// // console.log(emp1);

// class manager extends employee {
//     constructor(p, n){
//         super(n);//
//         this.pancard=p;
        

//     }
    
// }
// let mng = new manager("hii","shyam");
// console.log(emp1.sayhello());
// console.log(employee.sayhello());
//============================================================
//MIXING

let usefullmethods={
    sayhi(){
        console.log("hii......");
    },
    saybye(){
        console.log("bye.......");

    }
}

class user{
    constructor(){
        this.name="vitthal";
    }
}

class student extends user{

}

// Object.assign(user.prototype,usefullmethods);//useful methods are incuded into the class
 Object.assign(student.prototype,usefullmethods);//to extend a object in the class this is used
let obj1=new user();
let std1=new student();
console.log(std1.sayhi());

// console.log(obj1.sayhi());


