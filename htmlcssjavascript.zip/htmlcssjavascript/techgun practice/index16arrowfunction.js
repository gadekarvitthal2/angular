// function sum1(a,b){
//     return a+b;
// }
// let sum2=(a,b)=>{
//     return a+b;
// }

// console.log(sum1(15,15));
// console.log(sum2(20,20));

// let sum=(a,b)=>a+b;
// console.log(sum(25,15));

//-------------------------------------------------------------------
//callback function

function sayhello(){

    console.log("hello......");

}
function say(a,b){
    // sayhello();
    console.log(a+b);
    sayhello();
   }
say(10,20);


