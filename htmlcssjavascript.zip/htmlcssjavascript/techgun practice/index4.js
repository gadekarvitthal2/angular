

function calculator(value1, value2, operation) 
{

    var result;

    if (operation == addition) {
        result = value1 + value2;

        console.log("your addition is :" + result)
    }
    else if (operation == subtraction) {
        if (value1 > value2) {
            result = value1 - value2;
            console.log("your subtraction is :");
        }

        else {
            console.log("first value should be greater");
        }
    }

    else if (operation == multiplication) {
        result = value1 * value2;

        console.log("your multiplication is :" + result);


    }

    else if (operation == division) {
        result = value1 / value2;

        console.log("your division is :" + result);
    }

    else if (operation == reminder) {
        if (value1 > value2) {
            result = value1 / value2;
            console.log("your reminder is :" + result);
        }

        else {
            console.log("first value should be greater");
        }
    }
    else if(value1==null||value2==null){
        console.log("Pls enter any alue");
    }

    else{
        console.log("Somting went wrong");
    }

}

