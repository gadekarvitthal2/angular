// function function1(){
// return ["vitthal","gadekar",50000,51];
// }
// //let name1=function1();//call as well as assign;
// let[name,surname,sallry,id,satyam=50]=function1();

// console.log(satyam); 
// function greekycode(){
//     var language="javascript";
//     console.log(language);//javascript
//     function displaylanguage(){//javascript
//         console.log(`this is the way to express something${language*2}        
//         move on the way`);
//     }
//     return displaylanguage();

// }
// var display=greekycode();

// let book={
//     name1:"the king",
//     pages:300,
//     price:200,
//     address:{
//         city:"jalna",
//         state:"maharashtra"
//     }
// }
// // let{name1,pages,price}=book;
// let{name1:title,pages,price:pricename=800,address:{city:cityname,state,country="india"}}=book;

// console.log(pricename);







