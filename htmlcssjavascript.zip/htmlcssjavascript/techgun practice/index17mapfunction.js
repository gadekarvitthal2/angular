let array=[2,5,6,10,12,15];

// let newarray=[];
// for(let i=0;i<array.length;i++){
//     newarray[i]=array[i]*2;
// }
console.log(array);
// console.log(newarray);


//map function

// let newarray=array.map(function(val){
//     return val*2
// })

let array1=array.map((val)=>val*2);//by using arrow function

console.log(array1);




