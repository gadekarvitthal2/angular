var cars = ["Honda","TATA","Mahindra","Toyota","Hyundai","VolksWagen","Skoda","Maruti-Suzuki"];


                     //8
 for(var i = 0; i < cars.length; i++){
    console.log( cars[i] );
}
cars.forEach(i => {
    console.log("array is "+i);
    
});