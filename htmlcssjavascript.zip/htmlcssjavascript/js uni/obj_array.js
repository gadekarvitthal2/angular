// var a=40;
// var b=20;
// var c=a+b;
// console.log("the addition is :"+c);
// c=a-b;
// console.log("the subtraction is : "+c);
// c=a*b;
// console.log("the multiplication is : "+c);
// c=a/b;
// console.log("the division is : "+c+" is correct");

// if(a==b){
//     console.log(a+"and"+ b+" are equal value");
// }
// else{
//     console.log(a+"and"+ b+" are not equal value");
// }
var obj_bank={                     //first Object Bank
    name:"SBI",
    ifsc_code:411038,
    city:"Pune"
             };
             var obj_person={                      //Second Object Person
                name:"vitthal",
                surname:"Gadekar",
                mo_number:7219039013,
                obj_bank,                    //Bank object is declared In person obj
            };
            var company={
                "name":"infosys",
                city:"mumbai",
                no_employees:10000,
            };
            var objarray=[obj_person,obj_bank,company];

console.log(objarray[1].city);
 