let arr=[{
        "name":"rohit",
        "age":25,
        "location":"mumbai"
    },
    {
        "name":"virat",
        "age":24,
        "location":"banglore"
    },
    {
        "name":"dinesh",
        "age":27,
        "location":"mumbai"
    },
    {
        "name":"shikhar",
        "age":27,
        "location":"delhi"
    }
,{
        "different":25
}]
    




























//     var obj = {};
// arr.forEach((Element)=>{
// //         console.log(Element.name)
   
// obj[newParamArr[Element]] = paramVal[Element];
    
//     })
let unique=[];
    unique = arr.filter((item, i, ar) => ar.indexOf(item) == i);
        console.log();

