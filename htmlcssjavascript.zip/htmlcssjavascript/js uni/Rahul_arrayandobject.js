//array       0,1,2,3,4,5,6

var dummy = {
    "name":"rahul",
    "location":"satara"
}

var dummy_2 = {
    "job":"develper",
    "techstack":"MEAN"
}

var dummy_3 = {
    "company":"google",
    "designation":"L2support"
}


var array1 = [dummy,dummy_2,dummy_3];
var array2 = [1,2,3,4]
var array = [array1,array2];

console.log(array);



var naam = "rahul";

var address = {
    "city":"pune",
    "pincode":"415001",
    "state":"Maharashtra",
    "country":"India"
}

var lat_long = [78.08,87.0909]

var object = 
{
    "name":naam,
    "location":"mumbai",
    "mobile":8574979457,
    "isActive":true,
    "address":address,
    "lat_long":lat_long
}

//console.log(object.address.country);
