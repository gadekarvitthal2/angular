var mumbaiWins = 'superover';

if(mumbaiWins == 'true'){

console.log('party');

} else if(mumbaiWins == 'false'){

    console.log('sad');

} else if(mumbaiWins == 'superover'){

    console.log('very happy ');
    
} else {
    console.log('no party');
}