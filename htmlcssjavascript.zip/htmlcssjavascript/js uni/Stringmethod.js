// var vitthal="5";
//console.log(typeof +" "+vitthal);
// var newtype=String (vitthal);
// console.log(typeof vitthal);
//========================================================
//concatination
// var x="vitthal";
// var y="gadekar";
// var name=x.concat(y);

// name=x+y;
// console.log(name);
//============================================================
//string compare
// if(x=="vitthal"){
//     console.log("equal");
// }
// else{
//     console.log("not equal");
// }

//===========================================================
//sub string
let name1="my name is vitthal is gadekar";
// let substring=name1.substring(0,18);
// console.log(substring);

//====================================================
//
//indexof()
// let indexof1=name1.indexOf("gadeka");
// console.log(indexof1);
//=================================================
//replace()

// let vitthal=name1.replace("is","my");
// console.log(vitthal);
//==========================================
//includes
let vitthal=name1.includes("vitthal");
console.log(vitthal);






