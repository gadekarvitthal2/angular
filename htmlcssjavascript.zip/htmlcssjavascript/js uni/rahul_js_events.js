function printFun(){
    console.log('printed from html file');
}