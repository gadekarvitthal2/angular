// let vitthal=["vitthal","shyam","kartik","pappa"];
// let asset=[1,2,3,4,5,6];

// console.log(asset);
// vitthal[1]="ram";//updating an array; but assign first;

//=================================================
// vitthal.unshift("gadekar");//add element at first element
// console.log(vitthal);
// vitthal.shift();
// console.log(vitthal);//remove element at first element and not need to parameter
// vitthal.pop();//no parameters
// console.log(vitthal);//push to first index;
// vitthal.push("pappa");//push to last index
// console.log(vitthal);//empty array

// vitthal.length=1;//if 0 then empty but 1 then have a element
// console.log(vitthal);

//================================

// var name1=Array.isArray(asset);//Array.isarray() returns true or false
// console.log(name1);

// var string1="my collage is very good";
// var array1=string1.split(" ");//make array to string;
// console.log(array1);
//=====================================================
//concate
// let array1=vitthal.concat(asset);

// vitthal.concat(asset);
// console.log(array1);

//====================================================
//multidimentional Array

let vitthal=["vitthal","shyam","kartik","pappa"];
            // [1,2,3,4,5],
            // ["pune","mumbai","kolkata"]];
// console.log(vitthal[2][2]);
// let ramu=vitthal.length;
// for(let i=0;i < vitthal.length;i++){
//     console.log(vitthal[i]);
// }
vitthal.forEach((element)=>{
    console.log(element);
})

Array.forEach((element)=>{
    console.log()
})







