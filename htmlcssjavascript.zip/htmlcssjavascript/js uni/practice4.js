
console.log("operation should be addition,subtraction,multilpition,division,reminder");
function calculator(value1, value2, operation) {

    var result;
    var add = operation;
    var sub = operation;
    var div = operation;
    var mul = operation;
    var rem = operation;

    if (value1 == null || value2 == null) {
        console.log("Pls enter any value");
    }
    else if (add == "addition") {
        result = value1 + value2;

        console.log("your addition is :" + result)
    }

    else if (sub == "subtraction") {
        if (value1 >= value2 ) {
            result = value1 - value2;
            console.log("your subtraction is :" + result);
        }

        else {
            console.log("first value should be greater");
        }
    }

    else if (mul == "multiplication") {
        result = value1 * value2;

        console.log("your multiplication is :" + result);


    }

    else if (div == "division") {
        result = value1 / value2;

        console.log("your division is :" + result);
    }

    else if (rem == "reminder") {
        if (value1 > value2) {
            result = value1 % value2;
            console.log("your reminder is :" + result);
        }

        else {
            console.log("first value should be greater");
        }

    }
    else {
        console.log("Something went wrong");
    }


}
calculator(40,20, "addition");
calculator(40,20, "subtraction");
calculator(40,20, "multiplication");
calculator(40,20, "division");
calculator(40,20, "reminder");
