//to check age eligibility for voting

var age = 21;

if (age == null) {
    console.log("please enter your age");
}
else if (age >= 18) {
    console.log("you are eligible for vote");
}
else {
    console.log("you are not eligible for vote");
}
//---------------------------------------------------------

//Array decalration and index
var array=["vitthal","shyam","kartik","tai"];
console.log(array);
console.log(array[0]);
 
//---------------------------------------------------------------------
//object declaration Bank

var obj_bank={                     //first Object Bank
    name:"SBI",
    ifsc_code:411038,
    city:"Pune"
             };
      console.log(obj_bank.name);       //name key acess by .
//----------------------------------------------------------------------
//object contain object access another object

var obj_person={                      //Second Object Person
    name:"vitthal",
    surname:"Gadekar",
    mo_number:7219039013,
    obj_bank,                    //Bank object is declared In person obj
};
console.log(obj_person.obj_bank);
console.log("my name is :"+obj_person.name+" and bank is :"+obj_bank.name);
//-----------------------------------------------------------------------
var company={
    name:"infosys",
    city:"mumbai",
    no_employees:10000,
};

//------------------------------------------------------------------------
// Array contain object and acess

var objarray=[obj_person,obj_bank,company];
console.log(objarray[2].name);
        
//-------------------------------------------------------------------
//multidimentional Array

var multi_array=[["rahul","ganesh",10],
                 ["swati","john",20]];
  console.log(multi_array[1][2]);





