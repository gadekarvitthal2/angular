
function addition(input1,input2){
var a = input1;
var b = input2;
var result = a + b ;
console.log('addition of a and b is :' + result);
}

addition(12,13);

function calculator(input1,input2,operation){
    var a = input1;
    var b = input2;
    var operation = operation
    var result;
    console.log(operation);
    if(operation == 'addition'){
        result = a + b;
    } else if(operation == 'multiplication'){
        result = a * b;
    } else if (operation == 'division'){
        result = a / b;
    } else if (operation == 'substraction'){
        result = a - b;
    } else {
        console.log('no operation found');
    }

    console.log('calculation is : ' + result);
}

calculator(5,2,'substraction');
calculator(5,2,'addition');
calculator(5,2,'multiplication');
calculator(5,2,'division');



    

















