let arr = [{
    "name": "rohit",
    "age": 25,
    "location": "mumbai"
},
{
    "name": "virat",
    "age": 24,
    "location": "banglore"
},
{
    "name": "dinesh",
    "age": 27,
    "location": "mumbai"
},
{
    "name": "shikar",
    "age": 27,
    "location": "delhi"
}];


//------------------------------------------------------------


// 1.foreach on given array
// arr.forEach((item)=>{
//     console.log(item);
// })

//-----------------------------------------------------------

// 2.log only names on given array
//  arr.forEach((item)=>{
//     console.log(item.name);
//  })

//----------------------------------------------------------

//by using for loop
// for (let item of arr) {
//     console.log(item);
// }

//----------------------------------------------------------
//3. Create 2 separate array for age greater than 25 and less than 25

//  let arrayless=[];
// let arraygrater=[];
// arr.forEach((item)=>{
//     if(item.age>=25){
//         arraygrater.push(item);
//     }
//     else{
//         arrayless.push(item);

//     }
// })
// console.log("greter than 25:   "+JSON.stringify (arraygrater)+'\n');
// console.log("less than 25:  "+JSON.stringify (arrayless));
//-----------------------------------------------------------------------
//4 print name where age is 27
// arr.forEach((Element)=>{
//     if(Element.age==27){
//         console.log(Element.name);

//     };
// });
//---------------------------------------------------------------------
//5 print name where age is 27 and location is mumbai
// arr.forEach((Element)=>{
//     if(Element.age==27 && Element.location=="mumbai"){
//         console.log(Element.name);
//     }

// })
//------------------------------------------------------------------

//6 create array of keys of objects given in array

// let arraykeys=[]; //empty array
// arr.forEach((Element)=>{

//     arraykeys=Object.keys(Element);//here we assingn object.keys to arraykeys array 
//      console.log(arraykeys); //array keys printed
// })

//---------------------------------------------------------------------

// 7 create array of valueof objects given in array

// let arrayvalues=[];
// arr.forEach((Element)=>{
//     arrayvalues=Object.values(Element);
//     console.log( arrayvalues);
// })

//--------------------------------------------------------------------------

//8. create array of keys of objects given in array and keys must be unique

// let arraykeys=[]; //empty array
// arr.forEach((i)=>{

//     arraykeys=Object.keys(i);//here we assingn object.keys to arraykeys array 

// })
// function f1(){
// let newarray=[];
// arraykeys.forEach((item)=>{
//     if (newarray.indexOf(arraykeys[item]) === -1) {
//         newarray.push(arraykeys[item]);
//     }
//    });
//    console.log (arraykeys);
// }
// f1();


//--------------------------------------------------------------------------


//using set method
// let uniqueItems = [...new Set(arraykeys)]
// console.log(uniqueItems);
//----------------------------------------------------------------------


//using filter method
// let unique=[];
//     unique = arraykeys.filter((item, i, ar) => ar.indexOf(item) ===i);     
// console.log(unique);


//---------------------------------------------------------------------------
//9 create separate arrays for each object in array
// var sorted = [];
// var mergedarr = [];
// for (var i = 0, max = arr.length; i < max; i++) {
//   if (sorted[arr[i].name] == undefined) {
//     sorted[arr[i].name] = [];
//   }
//   sorted[arr[i].name].push(arr[i]);

// }
// console.log(sorted["shikar"]);
// console.log(sorted["virat"]);
// console.log(sorted["dinesh"]);
// console.log(sorted["rohit"]);
//-------------------------------------------------------------------
//10.10  create separate arrays for each object in array and merge arrays in single array


var sorted = [];
var mergedarr = [];
for (var i = 0, max = arr.length; i < max; i++) {
    if (sorted[arr[i].name] == undefined) {
        sorted[arr[i].name] = [];
    }
    sorted[arr[i].name].push(arr[i]);
    mergedarr.push(arr[i])  //here we added in single array
}


console.log(mergedarr);
















