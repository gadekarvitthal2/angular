var flag=0;

function navigator(x) {
    flag = flag + x;
    // console.log(flag);
    slideshow(flag);
    
    


}

slideshow(flag);

function slideshow(flag) {
    var slides = document.getElementsByClassName('slide');
    var vitthal=flag;

    for(let i of slides){
       
        i.style.display = "none";    
    }
    
  console.log();
    if(slides.length-1<vitthal){
        vitthal=0;
        // flag=0;    
    }
    
    if(vitthal<0){
        
        vitthal=slides.length-1;
        
        
    }
    
    
    slides[vitthal].style.display = "block";//we need to declare script in the body after initilizatin

} 































// let flag=0;
// function left(flag){
//     flag=flag+1;
//     num=flag;
//     slides();

// }
// var num;

// function right(flag){
//     flag=flag-1;
//     flag=num;
//     slides();
// }

// function slides(){
//     
//     for (const i of slides) {
//         console.log(i.length);
//         slides[i].style.display="block";
        
//     }

// }
// slides();

















